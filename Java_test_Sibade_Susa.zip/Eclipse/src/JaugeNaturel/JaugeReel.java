package JaugeNaturel;

import TransportEnCommun.tec.Transport.IJauge;

/**
 * Réalisation d'une Jauge avec des entiers naturels.
 * <p>
 * Un objet Jauge définit un niveau et un intervalle ouvert ]vigieMin, vigieMax[.
 * Le niveau d'une jauge n'est pas limité aux valeurs dans l'intervalle.
 * <p>
 * L'état d'une jauge correspond à la position de son niveau par rapport à
 * l'intervalle ]vigieMin, vigieMax[.
 * Une jauge définit trois etats :
 * <ul>
 * <li>vert niveau dans l'intervalle,
 * <li>rouge niveau supérieur à l'intervalle,
 * <li>bleu niveau inférieur à l'intervalle.
 * </ul>
 *
 * @author georgy
 * @since 2006-2007
 */
public class JaugeReel implements IJauge{
  private float valeur;
  private final float min;
  private final float max;

  /**
   * Construit une instance en précisant la valeur de départ de la Jauge
   * et l'intervalle de vigie.
   *
   * @param vigieMin valeur minimale de l'intervalle de vigie.
   * @param vigieMax valeur maximale de l'intervalle de vigie.
   * @param depart   valeur initiale de la jauge.
   */
  public JaugeReel(JaugeNaturel JN) {
    valeur = JN.getValeur()/1000;
    min = JN.getMin()/1000;
    max = JN.getMax()/1000;

  }
  
  public JaugeReel(float vigieMin, float vigieMax, float depart) throws IllegalArgumentException{
	  if(vigieMin >= vigieMax){throw new IllegalArgumentException();}

	  valeur = depart;
	  min = vigieMin;
	  max = vigieMax;
	   
  }


  /**
   * L'état de la jauge est-il rouge ?
   *
   * @return vrai si niveau >=  vigieMax.
   *
   */
  public boolean estRouge() {
    return valeur >= max;
  }

  /**
   * L'état de la jauge est-il vert ?
   *
   * @return vrai si niveau appartient à ]vigieMin, vigieMax[.
   *
   */
  public boolean estVert() {
    //return !(estBleu() && estRouge());
    return valeur > min && valeur < max;
  }

  /**
   * L'état de la jauge est-il bleu ?
   *
   * @return vrai si niveau <= vigieMin.
   */
  public boolean estBleu() {
    return valeur <= min;
  }

  /**
   * Incrémente le niveau d'une unité.
   * L'état peut devenir supérieur à vigieMax.
   */
  public void incrementer() {
    valeur+=(float)1;
  }

  /**
   * Décrémente le niveau d'une unité.
   * L'état peut devenir inférieur à la vigieMin.
   */
  public void decrementer() {
	  valeur=(float) (valeur-1);
  }


  /**
   * Cette méthode est héritée de la classe {@link java.lang.Object}.
   * Très utile pour le débogage, elle permet de fournir une
   * chaîne de caractères correspondant a l'état d'un objet.
   * <p> Un code par défaut est définit dans
   * {@link java.lang.Object#toString() la classe Object}
   * Il faut adapter (redéfinir) le code de cette méthode à chaque classe.
   *
   * Pour les chaînes de cararctères, l'opérateur + correspond a la concaténation.
   * Les valeurs numériques sont alors convertit en ascii.
   * Si l'état d'une instance de cette classe est min=-456, max=23,
   * valeur=-7, la concaténation donne la chaîne "<-7 [-456,23]>".
   */
  @Override
  public String toString() {
    return "<" + valeur + " [" + min + "," + max + "]>";
  }
  

  public float getValeur(){return this.valeur;}
  
  public float getMin(){return this.min;}
  
  public float getMax(){return this.max;}
  
}
